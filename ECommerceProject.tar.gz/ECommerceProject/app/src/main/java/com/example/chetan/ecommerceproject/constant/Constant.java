package com.example.chetan.ecommerceproject.constant;


import java.util.ArrayList;
import java.util.List;


public final class Constant {
    public static final List<Integer> QUANTITY_LIST = new ArrayList<Integer>();



    public static final String CURRENCY = "$";
    public static final int MOBILES=1;
    public static final int CLOTHES=2;
    public static final int SHOES=3;
    public static final int CAMERAS=4;
    public static final int Laptops =5;
}
